import React from 'react';
import ItemImg from './ItemImg';
import TextBig from './TextBig';


export default function Galery(){
    return(
        <div className="one-column content">
            <TextBig label="" />
            <div className="imagens1">
                <ItemImg src="./natal1.PNG" label="Bob"/>
                <ItemImg src="./natal2.PNG" label="Mia"/>
                <ItemImg src="./natal3.PNG" label="Tobi"/>
            </div>
            <div className="imagens2">
                <ItemImg src="./natal4.PNG" label="Yummi"/>
                <ItemImg src="./natal5.PNG" label="Teo"/>
                <ItemImg src="./natal6.PNG" label="Bili"/>
            </div>
        </div>
    )
}