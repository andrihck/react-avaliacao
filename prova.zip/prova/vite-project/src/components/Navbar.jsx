import React from 'react';


export default function Navbar(){
    return(
        <nav className="navbar">
          <li><a href="../App.jsx"></a></li>
          <li><a href=""></a></li>
          <li><a href=""></a></li>
        </nav>
    )
}