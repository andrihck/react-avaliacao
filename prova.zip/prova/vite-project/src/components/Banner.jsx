import React from 'react';
import TextBig from './TextBig';
import Button from './Button';


export default function Banner(){
    return(
        <div className='banner container'>
            <div className="two-column content">
                <div className="inner-content">
                    <TextBig label="Comemoração de Natal"/>
                    <p>‎ </p>
                    <p>Celebrar o Natal é renovar nosso amor no Senhor. Aquele que veio um dia nos trazer a salvação continua vindo ao nosso encontro todos os dias do ano, nas mais diversas pessoas e situações. Muitos assumem, no tempo natalino, a “síndrome do Papai Noel”. Do dia para a noite, fazem um processo de conversão relâmpago. O significado do Natal é o nascimento de Jesus Cristo e sua comemoração anual, que acontece há mais de 1600 anos no dia 25 de dezembro. Natal se refere a nascimento ou ao local onde alguma pessoa nasceu. Por exemplo, a expressão "cidade natal" indica a cidade onde um determinado indivíduo nasceu.</p>
                    <p>‎ </p>
                    <p>Horário: 19:00 até as 23:00</p>
                    <p>‎ </p>
                    <p>Data:24 de Dezembro de 2024</p>
                    <p>‎ </p>
                    <p>Local:Escola Sesi São José</p>
                    
                </div>
            </div>
            <div className="two-column content">
                <img src="./natal.webp" alt="Natal" srcset="" />
            </div>
        </div>
    )
}